chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.log(request)
        console.log(sender)
        setIntervalX(fillNamePwd, 500, 6, request)
        sendResponse('content-script: message received');
        return true;
    })
    // window.onload = function() {
    //     request = {
    //         "username": "5291584673@qq.com",
    //         "password": "duobao&time2014",
    //         "config": {
    //             "auto_login": false,
    //             "extra_js": "document.querySelector(\".account-center-agreement-check\").click()",
    //             "login_url": "https://yuntu.oceanengine.com/yuntu_ng/login",
    //             "password_css": "input[name='password']",
    //             "submit_css": ".account-center-action-button",
    //             "username_css": "input[name='email']"
    //         }
    //     }
    //     sender = {
    //         "id": "egfjjmpldhhmfiemfafjahpfkahnjjgo",
    //         "origin": "null"
    //     }
    //     console.log(request)
    //     console.log(sender)
    //     setIntervalX(fillNamePwd, 3000, 1, request)
    // }

function setIntervalX(callback, delay, repetitions, request) {
    // 执行额外的js
    extra_js = request.config.extra_js
    if (extra_js) {
        // console.log('extra_js: ', extra_js)
        setTimeout(extra_js, 1)
    }
    let x = 0;
    let intervalID = window.setInterval(function() {
        var ret;
        //try {
        ret = callback(request);
        // } catch (err) {
        //     console.log('匹配元素出现错误')
        // }
        if (ret || ++x === repetitions) {
            window.clearInterval(intervalID);
        }
        if (ret) {
            clickSubmit(request)
        }
    }, delay);
}

function fillNamePwd(request) {
    // iframe中的表单匹配
    // let iframes = document.getElementsByTagName('iframe')
    // if (iframes.length > 0) {
    //     for (let i = 0; i < iframes.length; i++) {
    //         let iframe = iframes[i].contentWindow;
    //         let username = iframe.document.querySelector(request.config.username_css)
    //         if (!username) {
    //             console.log('username: ', username)
    //             keyboardInput(username, request.username)
    //         }
    //         let password = iframe.document.querySelector(request.config.password_css)
    //         if (!password) {
    //             console.log('password: ', password)
    //             keyboardInput(password, request.password)
    //         }
    //         if (!username && !password) {
    //             return true
    //         }
    //     }
    // }
    // 普通的表单匹配
    let username = document.querySelector(request.config.username_css)

    if (!username) {
        return false;
    }
    console.log('username: ', username)
        // username.value = request.username
    keyboardInput(username, request.username)

    let password = document.querySelector(request.config.password_css)
    if (!password) {
        return false;
    }
    console.log('password: ', password)
        // password.value = request.password
    keyboardInput(password, request.password)
    return true;
}

function clickSubmit(request) {
    if (request.config.auto_login) {
        let submit = document.querySelector(request.config.submit_css)
        console.log('submit button: ', submit)
        if (submit) {
            setTimeout(function() {
                submit.click()
            }, 100);
        }
    }
}

function keyboardInput(dom, st) {
    // let evt = new InputEvent('input', {
    //     inputType: 'insertText',
    //     data: st,
    //     dataTransfer: null,
    //     isComposing: false
    // });
    // dom.value = st;
    // dom.dispatchEvent(evt);
    dom.value = st;

    var event = document.createEvent('HTMLEvents');
    event.initEvent("input", true, true);
    event.eventType = 'message';
    dom.dispatchEvent(event);
}
console.log('content-script load end')