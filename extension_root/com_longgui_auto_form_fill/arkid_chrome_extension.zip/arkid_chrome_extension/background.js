// import { MD5 } from './node_modules/crypto-es/lib/md5.js';
// const rst = MD5("Message").toString();
// console.log(rst)
import CryptoJS from './node_modules/crypto-es/lib/index.js'

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('插件收到请求：', request)
  console.log('消息发送标签：', sender)
  if (request.type == "login") {
    let urlObject = new URL(sender.url)
    let arkidUrl = urlObject.origin
    let token = request.data.token
    let tenant = request.data.tenant_uuid
    let app_uuid = request.data.app_uuid
    let user_uuid = request.data.user_uuid
    let username = request.data.username

    chrome.storage.sync.set({ arkidUrl }, function () {
      console.log('arkidUrl is set to ', arkidUrl);
    });
    if (token && tenant && username && app_uuid && user_uuid) {
      getRedirectInfo(arkidUrl, tenant, token, app_uuid, user_uuid, username).then((result) => {
        console.log('获取信息结果: ', result)
        if (result.error) {
          sendResponse(result);
        } else {
          sendResponse({ 'error': 'OK' });
          console.log('开始跳转到应用', result.config)
          openAppLogin(sender.tab.id, username, result.password, result.config)
        }
      });
      return true;
    } else {
      sendResponse({ error: '消息格式不正确' });
      return true;
    }
  } else if (request.type == "addAccount") {
    let tenant_uuid = request.data.tenant_uuid
    let app_uuid = request.data.app_uuid
    let user_uuid = request.data.user_uuid
    let username = request.data.username
    let password = request.data.password
    addAccount(tenant_uuid, app_uuid, user_uuid, username, password).then(result => {
      if(result){
        sendResponse({error: 'OK'})
      }else{
        sendResponse({error: "用户名重复"})
      }
    })
    return true;
  }else if (request.type == "showPwd") {
    let tenant_uuid = request.data.tenant_uuid
    let app_uuid = request.data.app_uuid
    let user_uuid = request.data.user_uuid
    let username = request.data.username
    getPassword(tenant_uuid, app_uuid, user_uuid, username).then(result => {
        sendResponse(result)
    })
    return true;
  }else if (request.type == "setPwd") {
    let tenant_uuid = request.data.tenant_uuid
    let app_uuid = request.data.app_uuid
    let user_uuid = request.data.user_uuid
    let username = request.data.username
    let password = request.data.password
    setPassword(tenant_uuid, app_uuid, user_uuid, username, password).then(result => {
        sendResponse(result)
    })
    return true;
  }
});

async function getRedirectInfo(arkidUrl, tenant, token, app_uuid, user_uuid, username) {
  try {
    const account = await getAccountInfo(tenant, app_uuid, user_uuid, username)
    if (!account) {
      return { error: `该用户没有配置表单代填账号` }
    }
    let password = AES_CBC_DECRYPT(account.password, user_uuid)
    const config = await getAppConfigInfo(arkidUrl, tenant, token, app_uuid)
    if (!config.login_url) {
      return { error: `没有找到对应${app_uuid}的配置信息` }
    }
    return { password, config }
  } catch (e) {
    console.log(e);
    return { error: e.message };
  }
}

async function getAccountInfo(tenant, app_uuid, user_uuid, username) {
  let result = await chrome.storage.sync.get(['accounts']);
  let accounts = result.accounts;
  if (accounts) {
    let user_accounts = accounts[user_uuid]
    if (user_accounts && user_accounts.length) {
      return user_accounts.find(item => {
        return item.tenant_uuid == tenant && item.app_uuid == app_uuid && item.username == username;
      })
    }
  } else {
    return null;
  }
}

async function getAppConfigInfo(arkidUrl, tenant, arkidToken, app_uuid) {

  const url = `${arkidUrl}/api/v1/com_longgui_auto_form_fill/apps/${app_uuid}/`
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Token ${arkidToken}`
    }
  });
  console.log('App config result: ', response)
  if (!response.ok) {
    const message = `An error has occured: ${response.status}`
    throw new Error(message)
  }
  const config = await response.json()
  return config
}

async function openAppLogin(tabid, username, password, config) {
  let tab = await chrome.tabs.update(tabid, { url: config.login_url })
  chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
    if (tabId === tab.id && changeInfo.status == 'complete') {
      chrome.tabs.onUpdated.removeListener(listener);
      chrome.tabs.sendMessage(tabId, { username, password, config }, (response) => { console.log(response) })
    }
  })
}

/**
  * AES-256-CBC对称加密
  * @param text {string} 要加密的明文
  * @param secretKey {string} 密钥，43位随机大小写与数字
  * @returns {string} 加密后的密文，Base64格式
  */
function AES_CBC_ENCRYPT(text, secretKey) {
  var keyHex = CryptoJS.enc.Base64.parse(secretKey);
  var ivHex = keyHex.clone();
  // 前16字节作为向量
  ivHex.sigBytes = 16;
  ivHex.words.splice(4);
  var messageHex = CryptoJS.enc.Utf8.parse(text);
  var encrypted = CryptoJS.AES.encrypt(messageHex, keyHex, {
    "iv": ivHex,
    "mode": CryptoJS.mode.CBC,
    "padding": CryptoJS.pad.Pkcs7
  });
  return encrypted.toString();
}

/**
 * AES-256-CBC对称解密
 * @param textBase64 {string} 要解密的密文，Base64格式
 * @param secretKey {string} 密钥，43位随机大小写与数字
 * @returns {string} 解密后的明文
 */
function AES_CBC_DECRYPT(textBase64, secretKey) {
  var keyHex = CryptoJS.enc.Base64.parse(secretKey);
  var ivHex = keyHex.clone();
  // 前16字节作为向量
  ivHex.sigBytes = 16;
  ivHex.words.splice(4);
  var decrypt = CryptoJS.AES.decrypt(textBase64, keyHex, {
    "iv": ivHex,
    "mode": CryptoJS.mode.CBC,
    "padding": CryptoJS.pad.Pkcs7
  });
  return CryptoJS.enc.Utf8.stringify(decrypt);
}

async function addAccount(tenant_uuid, app_uuid, user_uuid, username, password) {
  password = AES_CBC_ENCRYPT(password, user_uuid)
  let {accounts} = await chrome.storage.sync.get('accounts')
  console.log('Accounts currently is ', accounts);
  if (!accounts) {
      accounts = {}
  }
  let user_accounts = accounts[user_uuid]
  if (user_accounts && user_accounts.length) {
      console.log('检查账号是否重复')
      let isDuplicate = user_accounts.find(item => {
          return item.tenant_uuid == tenant_uuid && item.app_uuid == app_uuid && item.username == username
      })
      console.log(isDuplicate)
      if (isDuplicate) {
          console.log('用户名已经存在');
          return false;
      }
      user_accounts.push({ tenant_uuid, app_uuid, username, password })
  } else {
      user_accounts = [{ tenant_uuid, app_uuid, username, password }]
  }
  accounts[user_uuid] = user_accounts
  await chrome.storage.sync.set({ accounts })
  return true
}

async function getPassword(tenant_uuid, app_uuid, user_uuid, username) {
  let password = ''
  let {accounts} = await chrome.storage.sync.get('accounts')
  if(!accounts) {
    return {password}
  }
  let user_accounts = accounts[user_uuid]
  if (user_accounts && user_accounts.length) {
      let target = user_accounts.find(item => {
          return item.tenant_uuid == tenant_uuid && item.app_uuid == app_uuid && item.username == username
      })
      if (target) {
        password = AES_CBC_DECRYPT(target.password, user_uuid)
      }
  }
  return {password}
}

async function setPassword(tenant_uuid, app_uuid, user_uuid, username, password) {
  let {accounts} = await chrome.storage.sync.get('accounts')
  if(!accounts) {
    return {error: '账号为空'}
  }
  let user_accounts = accounts[user_uuid]
  if (user_accounts && user_accounts.length) {
    let target = user_accounts.find(item => {
        return item.tenant_uuid == tenant_uuid && item.app_uuid == app_uuid && item.username == username
    })
    if (target) {
      password = AES_CBC_ENCRYPT(password, user_uuid)
      target.password = password
    }else{
      return {errpr: "没有找到该账号"}
    }
    await chrome.storage.sync.set({ accounts })
    return {error: 'OK'}
  }else{
    return {error: "该用户没有设置账号"}
  }
}