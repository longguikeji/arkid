console.log('Arkid chrome extension is working')
let download_hint_div = document.getElementById('download-arkid-chrome-extension')
console.log(download_hint_div)
download_hint_div.style.display = "none"

const app_uuid = document.getElementById('app_uuid').value
const tenant_uuid = document.getElementById('tenant_uuid').value
const user_uuid = document.getElementById('user_uuid').value
const save_type = document.getElementById('save_type').value
const placeholder = document.getElementById('placeholder').value

console.log(app_uuid, tenant_uuid, user_uuid, save_type)

const token = localStorage.getItem('token')

var div = document.createElement("div");
div.style.height = "100%"
div.innerHTML = `
<div id="accounts">
    <div>请选择登录账号：</div>
</div>
<div id="form">
    <div class="form-item">
        <label for="username">账号</label>
        <input id="username" placeholder="`+placeholder+`" type="text" />
    </div>
    <div class="form-item">
        <label for="password">密码</label>
        <input id="password" placeholder="请输入密码" type="password" />
    </div>
    <div class="form-item">
        <input id="submit" type="button" value="添加" />
    </div>
</div>
`
document.body.appendChild(div);

function process_result(accounts){
    console.log('accounts', accounts)
    if (accounts && accounts.length > 1) {
        document.getElementById('accounts').style.display = ""
        document.getElementById('form').style.display = "none"
        accounts_div = document.getElementById('accounts')
        let accountsList = createAccountsList(tenant_uuid, app_uuid, user_uuid, accounts)
        accounts_div.appendChild(accountsList)
    } else if (accounts && accounts.length == 1) {
        document.getElementById('form').style.display = "none"
        document.getElementById('accounts').style.display = "none"
        let username = accounts[0].username
        request = { type: "login", data: { tenant_uuid, app_uuid, user_uuid, username, token } }
        chrome.runtime.sendMessage(request, (response) => {
            console.log(response);
            document.getElementById('error').innerHTML = response.error
        });
    } else {
        document.getElementById('accounts').style.display = "none"
        submit_btn = document.getElementById('submit')
        submit_btn.addEventListener("click", function (event) {
            username = document.getElementById("username").value
            password = document.getElementById("password").value
            if (!username || !password) {
                alert('请输入用户名和密码')
                return false;
            }
            let request = { type: "addAccount", data: { tenant_uuid, app_uuid, user_uuid, username, password, token} }
            chrome.runtime.sendMessage(request, (response) => {
                console.log(response);
                if(response.error == 'OK') {
                    request = { type: "login", data: { tenant_uuid, app_uuid, user_uuid, username, token } }
                    chrome.runtime.sendMessage(request, (response) => {
                        console.log(response);
                        document.getElementById('error').innerHTML = response.error
                    });
                }else{
                    document.getElementById('error').innerHTML = response.error
                }
            });
        })
    }
}

getAccounts(tenant_uuid, app_uuid, user_uuid, save_type).then(accounts => {
    process_result(accounts)
})

function createAccountsList(tenant_uuid, app_uuid, user_uuid, accounts) {
    let frag = document.createDocumentFragment()
    for (let i = 0; i < accounts.length; i++) {
        let div = document.createElement('div');
        let username = accounts[i].username
        div.innerHTML = `<button>${username}</button>`
        div.addEventListener("click", function () {
            request = { type: "login", data: { tenant_uuid, app_uuid, user_uuid, username, token } }
            chrome.runtime.sendMessage(request, (response) => {
                console.log(response);
                const error_div = document.getElementById('error')
                error_div.innerHTML = response.error
            });
        })
        frag.appendChild(div)
    }
    return frag
}

async function getAccounts(tenant_uuid, app_uuid, user_uuid, save_type) {
    if(save_type=="database"){
        console.log('使用数据库保存')
        // 联网获取数据(先获取用户)
        await chrome.storage.sync.set({ 'save_type': 'database'});
        let request = { type: "getHttpAccount", data: {tenant_uuid, app_uuid, user_uuid, token } }
        chrome.runtime.sendMessage(request, (response) => {
            console.log(response);
            data = response.data
            var result_arr = new Array();
            for (var i = 0; i < data.length; i++) {
                item = data[i]
                result_arr.push({
                    "app_uuid": app_uuid,
                    "password": "",
                    "id": item.id,
                    "tenant_uuid": tenant_uuid,
                    "username": item.username
                })
            }
            if(result_arr.length>0){
                // 结果缓存一份
                var db_accounts = {}
                db_accounts[user_uuid] = result_arr
                chrome.storage.sync.set({'db_accounts':db_accounts})
                // 执行结果处理程序
                process_result(result_arr)
                return null
            }else{
                return null
            }
        });
    }else{
        console.log('使用浏览器保存')
        await chrome.storage.sync.set({ 'save_type': 'web'});
        const result = await chrome.storage.sync.get(['accounts']);
        if(!result) {
            accounts = {};
            await chrome.storage.sync.set({ accounts });
            return null;
        }
        let accounts = result.accounts
        if (!accounts) {
            return null;
        }
        const user_accounts = accounts[user_uuid]
        if (user_accounts && user_accounts.length) {
            return user_accounts.filter(item => {
                return item.tenant_uuid == tenant_uuid && item.app_uuid == app_uuid;
            })
        } else {
            return null;
        }
    }
}
