chrome.storage.sync.get("arkidUrl", async ({ arkidUrl }) => {
  if (arkidUrl) {
    // urlInput.value = arkidUrl;
    console.log('当前ArkId Url：', arkidUrl)
    let urlPattern = `${arkidUrl}/*`
    let tabs = await chrome.tabs.query({ currentWindow: true, url: urlPattern });
    console.log("当前浏览器打开的ArkId页签：", tabs)
    if (tabs.length != 0) {
      console.log("开始获取token...")
      injectionResults = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        function: sendToken,
      });
      console.log('获取token结果: ', injectionResults);
      if (injectionResults && injectionResults.length) {
        const token = injectionResults[0].result.token
        const tenant = injectionResults[0].result.tenant.replaceAll('-', '')
        console.log(token, tenant)
        let userInfo = await getUserInfo(arkidUrl, token, tenant)
        console.log('用户信息', userInfo)
        let user_uuid = userInfo.data.id.replaceAll('-', '')
        setUserInfo(userInfo.data);
        let response = await getAppList(arkidUrl, token, tenant)
        appList = response.result
        console.log('开始设置appList', appList)
        await chrome.storage.sync.set({ appList });
        renderAppSelect(user_uuid, tenant, appList)
        await setTable(tenant, user_uuid)
      }
    };
  }

});

function setUserInfo(userInfo) {
  console.log('显示用户信息：', userInfo)
  if (userInfo) {
    let div = document.createElement('div')
    div.textContent = `用户名：${userInfo.username}`
    userInfo = document.getElementById("userInfo")
    userInfo.appendChild(div)
  }
}


function sendToken() {
  let token = localStorage.getItem('token')
  let tenant = localStorage.getItem('tenant_id')
  console.log('send token to arkid extension')
  return { token, tenant }
}

async function setTable(tenant_uuid, user_uuid) {
  let userAccounts = await getUserAccounts(tenant_uuid, user_uuid)
  console.log('用户账户', userAccounts)
  if (!userAccounts) {
    return
  }
  let str = ''
  userAccounts.forEach(function (app) {
    if (app.accounts && app.accounts.length) {
      str += `
        <tr style="background:#45b9aa; width:100%">
          <td>${app.app_name}</td>
        </tr>
      `
      app.accounts.forEach(function (account, index) {
        str += `
          <tr>
            <td style="width:30%">${account.username}</td>
            <td style="width:30%">
              <span name="pwd-hide" data-index="${account.app_uuid}-${index}">******</span>
              <input name="pwd" data-index="${account.app_uuid}-${index}" style="display:none" />
            </td>
            <td style="width:20%; text-align:right">
              <button name="modify" data-index="${account.app_uuid}-${index}" data-user="${user_uuid}" data-tenant="${tenant_uuid}" data-app="${account.app_uuid}" data-username="${account.username}" >修改</button>
              <button name="cancel" data-index="${account.app_uuid}-${index}" style="display:none">取消</button>
            </td>
            <td style="width:20%;">
              <button name="del" data-index="${account.app_uuid}-${index}" data-user="${user_uuid}" data-tenant="${tenant_uuid}" data-app="${account.app_uuid}" data-username="${account.username}">删除</button>
              <button name="confirm" data-index="${account.app_uuid}-${index}" data-user="${user_uuid}" data-tenant="${tenant_uuid}" data-app="${account.app_uuid}" data-username="${account.username}" style="display:none">确定</button>
            </td>
          </tr>
        `
      })
    }
  })
  let tBody = document.querySelector('tbody')
  tBody.innerHTML = str
}


async function getUserInfo(arkidUrl, arkidToken, tenant) {

  const url = `${arkidUrl}/api/v1/mine/tenant/${tenant}/profile/`
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Token ${arkidToken}`
    }
  });
  if (!response.ok) {
    const message = `An error has occured: ${response.status}`
    throw new Error(message)
  }
  const userinfo = await response.json()
  return userinfo
}

async function getAppList(arkidUrl, arkidToken, tenant) {

  const url = `${arkidUrl}/api/v1/com_longgui_auto_form_fill/apps/`
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': `Token ${arkidToken}`
    }
  });
  if (!response.ok) {
    const message = `An error has occured: ${response.status}`
    throw new Error(message)
  }
  const result = await response.json()
  return result
}

// 过滤出所有当前用户当前租户下的有使用权限的app的已经配置的账号
// 整理成[{app_uuid:xxx, app_name: xxx, accounts:[{username:xxx, password:xxx}]}]的形式
async function getUserAccounts(tenant_uuid, user_uuid) {
  console.log("获取用户账号", tenant_uuid, user_uuid)
  let result = []
  let { appList } = await chrome.storage.sync.get('appList')
  console.log("appList:", appList)
  if (!appList || appList.length == 0) {
    return result
  }

  let { accounts } = await chrome.storage.sync.get('accounts')
  console.log("accounts:", accounts)
  let user_accounts = accounts[user_uuid]
  if (!user_accounts || user_accounts.length == 0) {
    return result
  }

  for (let item of appList) {
    let app_uuid = item.uuid
    let app_name = item.name
    let accounts = user_accounts.filter((item) => {
      return item.tenant_uuid == tenant_uuid && item.app_uuid == app_uuid;
    })
    if (accounts.length == 0) {
      continue
    } else {
      result.push({ app_uuid, app_name, accounts })
    }
  };
  return result;
}

function switchButton(index, showOrigin) {
  for(let btn of ["pwd-hide", "del", "modify"]) {
    let items = document.getElementsByName(btn);
    for(let i=0; i<items.length; i++) {
      if(items[i].getAttribute('data-index') == index){
        if(showOrigin){
          items[i].style.display = "inline"
        }else{
          items[i].style.display = "none"
        }
      }
    };
  }

  for(let btn of ["pwd", "confirm", "cancel"]) {
    let items = document.getElementsByName(btn);
    for(let i=0; i<items.length; i++) {
      if(items[i].getAttribute('data-index') == index){
        if(showOrigin){
          items[i].style.display = "none"
        }else{
          items[i].style.display = "inline"
        }
      }
    };
  }
}

let tBody = document.querySelector('tbody')
tBody.addEventListener('click', async function (e) {
  if (e.target.getAttribute('name') == "del") {
    let user = e.target.getAttribute('data-user')
    let tenant = e.target.getAttribute('data-tenant')
    let app = e.target.getAttribute('data-app')
    let username = e.target.getAttribute('data-username')
    let res = await deleteAccount(user, tenant, app, username)
    if (res) {
      setTable(tenant, user)
    }
  }else if(e.target.getAttribute('name') == "modify"){
    let index = e.target.getAttribute('data-index');
    switchButton(index, false);
    let user = e.target.getAttribute('data-user')
    let tenant = e.target.getAttribute('data-tenant')
    let app = e.target.getAttribute('data-app')
    let username = e.target.getAttribute('data-username')
    let request = { type: "showPwd", data: { tenant_uuid: tenant, app_uuid: app, user_uuid: user, username: username} }
    chrome.runtime.sendMessage(request, (response) => {
      items = document.getElementsByName("pwd")
      for(let i = 0; i<items.length; i ++) {
        if(items[i].dataset.index == index) {
          items[i].value = response.password
        }
      }
    });
  }else if (e.target.getAttribute('name') == "cancel") {
    let index = e.target.getAttribute('data-index');
    switchButton(index, true);
  }else if (e.target.getAttribute('name') == "confirm") {
    let index = e.target.getAttribute('data-index');
    switchButton(index, true);
    let user = e.target.getAttribute('data-user')
    let tenant = e.target.getAttribute('data-tenant')
    let app = e.target.getAttribute('data-app')
    let username = e.target.getAttribute('data-username')
    let items = document.getElementsByName("pwd")
    let password = ''
    for(let i=0; i < items.length; i++) {
      if(items[i].dataset.index == index) {
        password = items[i].value
      }
    }
    if(!password) {
      alert('请输入密码');
      return false;
    }
    let request = { type: "setPwd", data: { tenant_uuid: tenant, app_uuid: app, user_uuid: user, username: username, password:password} }
    chrome.runtime.sendMessage(request, (response) => {
      if (response.error == 'OK') {
        console.log('更新密码成功')
        setTable(tenant, user)
      } else {
        console.log('更新密码失败')
      }
    });
  }
})

async function deleteAccount(user, tenant, app, username) {
  let { accounts } = await chrome.storage.sync.get("accounts")
  let userAccounts = accounts[user]
  if (userAccounts && userAccounts.length) {
    let index = userAccounts.findIndex(item => item.tenant_uuid == tenant && item.app_uuid == app && item.username == username)
    console.log('index', index)
    if (index == -1) {
      return false;
    } else {
      userAccounts.splice(index, 1)
      console.log('userAccounts', userAccounts)
      console.log('accounts', accounts)
      await chrome.storage.sync.set({ accounts });
      return true;
    }
  }
}

function renderAppSelect(user, tenant, appList) {
  if (appList && appList.length) {
    let select = document.getElementById('app')
    for (let item of appList) {
      let option = document.createElement("option")
      option.setAttribute("value", item.uuid);
      option.appendChild(document.createTextNode(item.name));
      select.appendChild(option)
    }
    submit = document.getElementById('submit')
    submit.addEventListener('click', async () => {
      let select = document.getElementById('app')
      let index = select.selectedIndex
      let app = select.options[index].value
      console.log(app)
      let username = document.getElementById("username").value
      let password = document.getElementById("password").value
      if (!username || !password) {
        alert("请输入账号和密码")
        return false;
      };
      let request = { type: "addAccount", data: { tenant_uuid: tenant, app_uuid: app, user_uuid: user, username: username, password: password } }
      chrome.runtime.sendMessage(request, (response) => {
        console.log(response);
        if (response.error == 'OK') {
          console.log('创建账号成功')
          setTable(tenant, user)
        } else {
          console.log('创建账号失败')
          alert("账号重复")
        }
      });
    })
  }
}

