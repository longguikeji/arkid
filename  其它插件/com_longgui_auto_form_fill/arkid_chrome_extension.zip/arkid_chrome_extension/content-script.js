chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log(request)
    console.log(sender)
    setIntervalX(fillNamePwd, 500, 6, request)
    sendResponse('content-script: message received');
    return true;
})


function setIntervalX(callback, delay, repetitions, request) {
    let x = 0;
    let intervalID = window.setInterval(function () {

       let ret = callback(request);

       if (ret || ++x === repetitions) {
           window.clearInterval(intervalID);
       }
       if(ret) {
           clickSubmit(request)
       }
    }, delay);
}


function fillNamePwd(request) {
    let username = document.querySelector(request.config.username_css)

    if (!username) {
        return false;
    }
    console.log('username: ', username)
    // username.value = request.username
    keyboardInput(username, request.username)

    let password = document.querySelector(request.config.password_css)
    if (!password) {
        return false;
    }
    console.log('password: ', password)
    // password.value = request.password
    keyboardInput(password, request.password)
    return true;
}

function clickSubmit(request) {
    if (request.config.auto_login){
        let submit = document.querySelector(request.config.submit_css)
        console.log('submit button: ', submit)
        if(submit) {
            submit.click()
        }
    }
}

function keyboardInput(dom, st) {
    let evt = new InputEvent('input', {
        inputType: 'insertText',
        data: st,
        dataTransfer: null,
        isComposing: false
    });
    dom.value = st;
    dom.dispatchEvent(evt);
}
console.log('content-script load end')